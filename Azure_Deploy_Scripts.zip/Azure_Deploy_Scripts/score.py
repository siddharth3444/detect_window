# import torch
from transformers import MaskFormerImageProcessor, MaskFormerForInstanceSegmentation
from azureml.core.model import Model
from PIL import Image
import torch
import json
import os
import io
import base64
import numpy as np
from skimage.measure import find_contours
from enum import Enum
# device = torch.device("cpu")

class LABEL_TYPE(Enum):
    WINDOW = 8
    WALL = 0
    FLOOR = 3

def init():
    global model
    global processor
    model_name = 'window_detect'
    model_path = Model.get_model_path(model_name)
    processor = MaskFormerImageProcessor.from_pretrained(model_path)
    model = MaskFormerForInstanceSegmentation.from_pretrained(model_path)

def query_image(img):
    target_size = (img.shape[0], img.shape[1])
    inputs = processor(images=img, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)
    outputs.class_queries_logits = outputs.class_queries_logits.cpu()
    outputs.masks_queries_logits = outputs.masks_queries_logits.cpu()
    results = processor.post_process_segmentation(outputs=outputs, target_size=target_size)[0].cpu().detach()
    results = torch.argmax(results, dim=0).numpy()
    return results

def find_boundary(label_value, mask):
    contours = find_contours(mask == label_value, 0.5, fully_connected="high")
    return contours

def extract_window_edges(window_contours):
    windows=[]
    for contour in window_contours:
        min_x = str(np.min(contour[:, 0]))
        max_x = str(np.max(contour[:, 0]))
        min_y = str(np.min(contour[:, 1]))
        max_y = str(np.max(contour[:, 1]))
        windows.append(
                        [
                          [min_x,min_y],  
                          [min_x,max_y],
                          [max_x,min_y],
                          [max_x,max_y],
                        
                        ]
                       )
    return windows


def send_response(mask):
      vertices=[]
      test=[]
      for contour in mask:
        test.extend(contour.ravel())
        ar=contour.astype(str)
        vertices.extend(ar.ravel())
      return vertices

def run(raw_data):
    data = json.loads(raw_data)
    base64_str = data['img']
    image = Image.open(io.BytesIO(base64.decodebytes(bytes(base64_str, "utf-8"))))
    numpydata = np.asarray(image)
    mask = query_image(numpydata)
    window_mask = find_boundary(LABEL_TYPE.WINDOW.value, mask)
    floor_mask = find_boundary(LABEL_TYPE.FLOOR.value, mask)
    window_contours = [np.fliplr(ctr).astype(np.int32) for ctr in window_mask]
    floor_contours = [np.fliplr(ctr).astype(np.int32) for ctr in floor_mask]
    windows_vertices=extract_window_edges(window_contours)
    w=send_response(window_contours)
    f=send_response(floor_contours)
    print(w)
    print(f)
    print(type(w))
    print(type(f))
        

    return {
            "predictions": {
                "window_contours":w,
                "floor_contours" :f,
                "windows_vertices":windows_vertices
            }
        }


